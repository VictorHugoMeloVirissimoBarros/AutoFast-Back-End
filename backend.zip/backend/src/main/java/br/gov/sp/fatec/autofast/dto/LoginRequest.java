package br.gov.sp.fatec.autofast.dto;

public record LoginRequest(String email, String senha) {}
