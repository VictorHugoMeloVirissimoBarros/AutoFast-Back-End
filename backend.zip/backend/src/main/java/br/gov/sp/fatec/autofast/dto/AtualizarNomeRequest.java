package br.gov.sp.fatec.autofast.dto;

public record AtualizarNomeRequest(String nome) {}
