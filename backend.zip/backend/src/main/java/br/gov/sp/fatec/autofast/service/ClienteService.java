package br.gov.sp.fatec.autofast.service;

import br.gov.sp.fatec.autofast.dto.ClienteRapidoRequest;
import br.gov.sp.fatec.autofast.model.Cliente;
import br.gov.sp.fatec.autofast.repository.ClienteRepository;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Locale;
import java.util.UUID;

@Service
public class ClienteService {
    private final ClienteRepository repository;
    private final PasswordEncoder passwordEncoder;

    public ClienteService(ClienteRepository repository, PasswordEncoder passwordEncoder) {
        this.repository = repository;
        this.passwordEncoder = passwordEncoder;
    }

    public List<Cliente> listar() { return repository.findAll(); }

    public Cliente buscarPorId(Long id) {
        return repository.findById(id).orElseThrow(() ->
                new ResponseStatusException(HttpStatus.NOT_FOUND, "Cliente não encontrado"));
    }

    public Cliente buscarPorEmail(String email) {
        return repository.findByEmail(email).orElseThrow(() ->
                new ResponseStatusException(HttpStatus.NOT_FOUND, "Cliente não encontrado"));
    }

    public List<Cliente> buscarPorNome(String nome) {
        return repository.findByNomeContainingIgnoreCase(nome);
    }

    public Cliente salvar(Cliente cliente) {
        cliente.setId(null);
        return repository.save(cliente);
    }

    public Cliente criarParaOrcamento(ClienteRapidoRequest dados) {
        if (dados.nome() == null || dados.nome().isBlank() ||
                dados.email() == null || dados.email().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Informe nome e e-mail do cliente.");
        }
        String email = dados.email().trim().toLowerCase(Locale.ROOT);
        if (repository.findByEmail(email).isPresent()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Já existe um cadastro com este e-mail.");
        }
        Cliente cliente = new Cliente();
        cliente.setNome(dados.nome().trim());
        cliente.setEmail(email);
        cliente.setTelefone(dados.telefone());
        // A senha aleatória evita criar uma credencial conhecida no cadastro rápido.
        cliente.setSenha(passwordEncoder.encode(UUID.randomUUID().toString()));
        return repository.save(cliente);
    }

    public Cliente atualizar(Long id, Cliente dados) {
        Cliente atual = buscarPorId(id);
        atual.setNome(dados.getNome());
        atual.setEmail(dados.getEmail());
        if (dados.getSenha() != null && !dados.getSenha().isBlank()) atual.setSenha(dados.getSenha());
        atual.setTelefone(dados.getTelefone());
        return repository.save(atual);
    }

    public void excluir(Long id) {
        if (!repository.existsById(id)) throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Cliente não encontrado");
        repository.deleteById(id);
    }
}
