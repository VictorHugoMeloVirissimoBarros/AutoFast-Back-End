package br.gov.sp.fatec.autofast.controller;

import br.gov.sp.fatec.autofast.dto.*;
import br.gov.sp.fatec.autofast.service.AuthService;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final AuthService auth;
    public AuthController(AuthService auth) { this.auth = auth; }

    @PostMapping("/cadastro")
    @ResponseStatus(HttpStatus.CREATED)
    public AuthResponse cadastro(@RequestBody CadastroRequest req) { return auth.cadastrar(req); }

    @PostMapping("/login")
    public AuthResponse login(@RequestBody LoginRequest req) { return auth.login(req); }

    @PatchMapping("/nome")
    public Map<String, String> atualizarNome(@RequestBody AtualizarNomeRequest req, Authentication authentication) {
        return Map.of("nome", auth.atualizarNome(authentication.getName(), req.nome()));
    }

    @DeleteMapping("/conta")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void excluirConta(Authentication authentication) {
        auth.excluirConta(authentication.getName());
    }
}
