package br.gov.sp.fatec.autofast.dto;

public record CadastroRequest(String nome, String telefone, String email, String senha, String perfil, String cidade) {}
