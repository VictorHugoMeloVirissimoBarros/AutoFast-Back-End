package br.gov.sp.fatec.autofast.service;

import br.gov.sp.fatec.autofast.dto.*;
import br.gov.sp.fatec.autofast.model.*;
import br.gov.sp.fatec.autofast.repository.UsuarioRepository;
import br.gov.sp.fatec.autofast.repository.ClienteRepository;
import br.gov.sp.fatec.autofast.repository.MecanicoRepository;
import br.gov.sp.fatec.autofast.repository.MensagemRepository;
import br.gov.sp.fatec.autofast.security.JwtService;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.Locale;

@Service
public class AuthService {
    private final UsuarioRepository usuarios;
    private final ClienteRepository clientes;
    private final MecanicoRepository mecanicos;
    private final MensagemRepository mensagens;
    private final PasswordEncoder encoder;
    private final AuthenticationManager authManager;
    private final JwtService jwt;

    public AuthService(UsuarioRepository usuarios, ClienteRepository clientes,
                       MecanicoRepository mecanicos, MensagemRepository mensagens, PasswordEncoder encoder,
                       AuthenticationManager authManager, JwtService jwt) {
        this.usuarios = usuarios;
        this.clientes = clientes;
        this.mecanicos = mecanicos;
        this.mensagens = mensagens;
        this.encoder = encoder;
        this.authManager = authManager;
        this.jwt = jwt;
    }

    public AuthResponse cadastrar(CadastroRequest req) {
        if (req.nome() == null || req.nome().isBlank() || req.email() == null ||
                req.email().isBlank() || req.senha() == null || req.senha().length() < 8) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "Informe nome, e-mail e senha com pelo menos 8 caracteres.");
        }
        String email = req.email().trim().toLowerCase(Locale.ROOT);
        if (usuarios.findByEmail(email).isPresent()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Este e-mail já está cadastrado.");
        }
        String perfil = req.perfil() == null ? "" : req.perfil().toLowerCase(Locale.ROOT);
        Usuario usuario;
        if (perfil.equals("cliente")) usuario = new Cliente();
        else if (perfil.equals("mecanico")) {
            Mecanico mecanico = new Mecanico();
            mecanico.setNivelAcesso("PADRAO");
            usuario = mecanico;
        } else throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Perfil inválido.");

        usuario.setNome(req.nome().trim());
        usuario.setEmail(email);
        usuario.setTelefone(req.telefone());
        usuario.setCidade(req.cidade());
        usuario.setSenha(encoder.encode(req.senha()));
        Usuario salvo = usuarios.save(usuario);
        return resposta(salvo, perfil.toUpperCase(Locale.ROOT));
    }

    public AuthResponse login(LoginRequest req) {
        if (req.email() == null || req.senha() == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Informe e-mail e senha.");
        }
        String email = req.email().trim().toLowerCase(Locale.ROOT);
        try {
            authManager.authenticate(new UsernamePasswordAuthenticationToken(email, req.senha()));
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "E-mail ou senha inválidos.");
        }
        Usuario usuario = usuarios.findByEmail(email)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED));
        return resposta(usuario, usuario instanceof Mecanico ? "MECANICO" : "CLIENTE");
    }

    @Transactional
    public String atualizarNome(String email, String novoNome) {
        if (novoNome == null || novoNome.isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Informe um nome válido.");
        }
        Usuario usuario = usuarios.findByEmail(email.toLowerCase(Locale.ROOT))
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Conta não encontrada."));
        usuario.setNome(novoNome.trim());
        usuarios.save(usuario);
        return usuario.getNome();
    }

    @Transactional
    public void excluirConta(String email) {
        Usuario usuario = usuarios.findByEmail(email.toLowerCase(Locale.ROOT))
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Conta não encontrada."));
        // Remove conversas antes dos orçamentos/usuário para respeitar as chaves estrangeiras.
        mensagens.deleteByRemetenteIdOrDestinatarioId(usuario.getId(), usuario.getId());
        if (usuario instanceof Cliente) {
            mensagens.deleteByOrcamentoClienteId(usuario.getId());
            clientes.deleteById(usuario.getId());
        } else if (usuario instanceof Mecanico) {
            mensagens.deleteByOrcamentoMecanicoId(usuario.getId());
            mecanicos.deleteById(usuario.getId());
        }
    }

    private AuthResponse resposta(Usuario usuario, String perfil) {
        return new AuthResponse(jwt.gerarToken(usuario.getEmail(), perfil), usuario.getId(),
                usuario.getNome(), usuario.getEmail(), perfil);
    }
}
