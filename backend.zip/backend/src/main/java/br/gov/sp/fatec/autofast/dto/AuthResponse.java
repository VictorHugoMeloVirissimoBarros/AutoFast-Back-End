package br.gov.sp.fatec.autofast.dto;

public record AuthResponse(String token, Long id, String nome, String email, String perfil) {}
