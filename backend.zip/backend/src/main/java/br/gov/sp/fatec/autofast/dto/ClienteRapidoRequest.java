package br.gov.sp.fatec.autofast.dto;

public record ClienteRapidoRequest(String nome, String telefone, String email) {}
