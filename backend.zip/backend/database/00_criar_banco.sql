-- Execute este arquivo conectado ao banco administrativo "postgres".
-- Execute apenas uma vez. O PostgreSQL nao permite CREATE DATABASE dentro de transacao.
CREATE DATABASE autofast_db
    WITH
    OWNER = postgres
    ENCODING = 'UTF8'
    TEMPLATE = template0;
